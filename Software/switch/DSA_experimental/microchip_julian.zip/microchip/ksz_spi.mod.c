#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

MODULE_INFO(intree, "Y");



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x8fe3c098, "__spi_register_driver" },
	{ 0xd10ca780, "device_remove_file" },
	{ 0x3ee5992, "ksz_switch_shutdown" },
	{ 0xbcab6ee6, "sscanf" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x7e2038ee, "_dev_warn" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x4442013d, "regmap_write" },
	{ 0x43b5be19, "_dev_err" },
	{ 0xf1415646, "ksz_switch_remove" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xdcb764ad, "memset" },
	{ 0x595757d9, "ksz_switch_alloc" },
	{ 0x26169fe8, "device_get_match_data" },
	{ 0x4829a47e, "memcpy" },
	{ 0xa483f191, "__devm_regmap_init_spi" },
	{ 0x117a279, "spi_setup" },
	{ 0x6ef6aaa5, "ksz_switch_register" },
	{ 0x6b96d755, "dev_err_probe" },
	{ 0xaebbf0ae, "device_create_file" },
	{ 0xe1b2de7f, "driver_unregister" },
	{ 0xf3ed1957, "regmap_read" },
	{ 0x3757b2ea, "ksz_switch_chips" },
	{ 0x47e64c59, "module_layout" },
};

MODULE_INFO(depends, "ksz_switch,regmap-spi");

MODULE_ALIAS("spi:ksz8765");
MODULE_ALIAS("spi:ksz8794");
MODULE_ALIAS("spi:ksz8795");
MODULE_ALIAS("spi:ksz8863");
MODULE_ALIAS("spi:ksz8864");
MODULE_ALIAS("spi:ksz8873");
MODULE_ALIAS("spi:ksz8895");
MODULE_ALIAS("spi:ksz9477");
MODULE_ALIAS("spi:ksz9896");
MODULE_ALIAS("spi:ksz9897");
MODULE_ALIAS("spi:ksz9893");
MODULE_ALIAS("spi:ksz9563");
MODULE_ALIAS("spi:ksz8563");
MODULE_ALIAS("spi:ksz8567");
MODULE_ALIAS("spi:ksz9567");
MODULE_ALIAS("spi:lan9370");
MODULE_ALIAS("spi:lan9371");
MODULE_ALIAS("spi:lan9372");
MODULE_ALIAS("spi:lan9373");
MODULE_ALIAS("spi:lan9374");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8765");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8765C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8794");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8794C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8795");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8795C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8863");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8863C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8864");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8864C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8873");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8873C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8895");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8895C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9477");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9477C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9896");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9896C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9897");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9897C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9893");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9893C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9563");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9563C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8563");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8563C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8567");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8567C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9567");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9567C*");
MODULE_ALIAS("of:N*T*Cmicrochip,lan9370");
MODULE_ALIAS("of:N*T*Cmicrochip,lan9370C*");
MODULE_ALIAS("of:N*T*Cmicrochip,lan9371");
MODULE_ALIAS("of:N*T*Cmicrochip,lan9371C*");
MODULE_ALIAS("of:N*T*Cmicrochip,lan9372");
MODULE_ALIAS("of:N*T*Cmicrochip,lan9372C*");
MODULE_ALIAS("of:N*T*Cmicrochip,lan9373");
MODULE_ALIAS("of:N*T*Cmicrochip,lan9373C*");
MODULE_ALIAS("of:N*T*Cmicrochip,lan9374");
MODULE_ALIAS("of:N*T*Cmicrochip,lan9374C*");

MODULE_INFO(srcversion, "14786E18E372BACCB46A3BC");
