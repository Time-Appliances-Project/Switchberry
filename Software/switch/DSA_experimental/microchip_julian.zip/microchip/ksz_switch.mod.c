#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.arch = MODULE_ARCH_INIT,
};

MODULE_INFO(intree, "Y");

KSYMTAB_DATA(ksz_switch_chips, "_gpl", "");
KSYMTAB_FUNC(ksz_switch_alloc, "", "");
KSYMTAB_FUNC(ksz_switch_shutdown, "", "");
KSYMTAB_FUNC(ksz_switch_register, "", "");
KSYMTAB_FUNC(ksz_switch_remove, "", "");

SYMBOL_CRC(ksz_switch_chips, 0x3757b2ea, "_gpl");
SYMBOL_CRC(ksz_switch_alloc, 0x595757d9, "");
SYMBOL_CRC(ksz_switch_shutdown, 0x03ee5992, "");
SYMBOL_CRC(ksz_switch_register, 0x6ef6aaa5, "");
SYMBOL_CRC(ksz_switch_remove, 0xf1415646, "");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xf60e41e7, "ietf_dscp_to_ieee8021q_tt" },
	{ 0xc1514a3b, "free_irq" },
	{ 0xaa122ee1, "irq_domain_xlate_twocell" },
	{ 0x4442013d, "regmap_write" },
	{ 0xec1ce3d0, "handle_level_irq" },
	{ 0x495231ea, "mul_u64_u64_div_u64" },
	{ 0x4a3ad70e, "wait_for_completion_timeout" },
	{ 0xfbd862b4, "devm_kmalloc" },
	{ 0x40b22cf5, "of_node_put" },
	{ 0xf01da5bc, "of_property_read_variable_u32_array" },
	{ 0x57674fd7, "__sw_hweight16" },
	{ 0x85670f1d, "rtnl_is_locked" },
	{ 0xe113bbbc, "csum_partial" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xa6257a2f, "complete" },
	{ 0x95381d73, "skb_clone_sk" },
	{ 0x3a4d6162, "dsa_enqueue_skb" },
	{ 0x608741b5, "__init_swait_queue_head" },
	{ 0xee8cf3e7, "irq_domain_remove" },
	{ 0x9835fb22, "gpiod_set_value_cansleep" },
	{ 0x2c7db649, "irq_dispose_mapping" },
	{ 0xae338bd9, "flow_rule_match_eth_addrs" },
	{ 0x1e6010d4, "ptp_clock_index" },
	{ 0x4829a47e, "memcpy" },
	{ 0x12dd7ad7, "dsa_register_switch" },
	{ 0x37a0cba, "kfree" },
	{ 0xc3055d20, "usleep_range_state" },
	{ 0x76d8fdb7, "devm_gpiod_get_optional" },
	{ 0xf6ebc03b, "net_ratelimit" },
	{ 0x1d4730b1, "of_get_next_available_child" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0x868f774, "ptp_find_pin" },
	{ 0x10634d6d, "ieee8021q_tt_to_tc" },
	{ 0x8e4882be, "ptp_parse_header" },
	{ 0x122c3a7e, "_printk" },
	{ 0xe6d2458e, "do_trace_netlink_extack" },
	{ 0x7522f3ba, "irq_modify_status" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x296695f, "refcount_warn_saturate" },
	{ 0xb2fcb56d, "queue_delayed_work_on" },
	{ 0xe46021ca, "_raw_spin_unlock_bh" },
	{ 0xc8e375d8, "irq_set_chip_and_handler_name" },
	{ 0x6cbbfc54, "__arch_copy_to_user" },
	{ 0x1744d40, "_dev_info" },
	{ 0x20b807a4, "ptp_classify_raw" },
	{ 0xc7150f7a, "flow_rule_match_basic" },
	{ 0x63e5acb9, "of_get_child_by_name" },
	{ 0x4dded69b, "ptp_cancel_worker_sync" },
	{ 0x43b5be19, "_dev_err" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0x79f32131, "ptp_clock_register" },
	{ 0x57be7d8c, "skb_complete_tx_timestamp" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0x365acda7, "set_normalized_timespec64" },
	{ 0xa12054b9, "dsa_unregister_switch" },
	{ 0xde89833a, "of_find_property" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0xaae0a698, "__irq_resolve_mapping" },
	{ 0x549525ef, "handle_nested_irq" },
	{ 0x65929cae, "ns_to_timespec64" },
	{ 0xdcb764ad, "memset" },
	{ 0x7e2038ee, "_dev_warn" },
	{ 0xf9c0b663, "strlcat" },
	{ 0xd9672b23, "ptp_clock_unregister" },
	{ 0x3b442ab3, "devm_mdiobus_alloc_size" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x37009fb1, "of_get_phy_mode" },
	{ 0xf3ed1957, "regmap_read" },
	{ 0x6fda9818, "regmap_bulk_write" },
	{ 0xdc76e206, "irq_domain_instantiate" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x9fa7184a, "cancel_delayed_work_sync" },
	{ 0xc6f46339, "init_timer_key" },
	{ 0x378d5136, "__devm_of_mdiobus_register" },
	{ 0xb104dc7c, "__kmalloc_cache_noprof" },
	{ 0xb43f9365, "ktime_get" },
	{ 0x890af475, "regmap_bulk_read" },
	{ 0x56470118, "__warn_printk" },
	{ 0x13e42833, "irq_create_mapping_affinity" },
	{ 0xffeedf6a, "delayed_work_timer_fn" },
	{ 0x49ed075c, "irq_domain_create_simple" },
	{ 0x12a4e128, "__arch_copy_from_user" },
	{ 0xc3690fc, "_raw_spin_lock_bh" },
	{ 0x20a789ac, "irq_set_chip_data" },
	{ 0xa65c6def, "alt_cb_patch_nops" },
	{ 0xd3dec1b, "_dev_crit" },
	{ 0x61697eb5, "regmap_update_bits_base" },
	{ 0x8fa9ef67, "of_device_get_match_data" },
	{ 0x31245a4d, "ptp_schedule_worker" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0x8a05ee50, "flow_rule_match_control" },
	{ 0x10076532, "dsa_switch_shutdown" },
	{ 0xf9a482f9, "msleep" },
	{ 0x6568f461, "kmalloc_caches" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x47e64c59, "module_layout" },
};

MODULE_INFO(depends, "dsa_core");


MODULE_INFO(srcversion, "3E47FB29025394ADDBA1539");
