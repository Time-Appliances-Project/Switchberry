#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

MODULE_INFO(intree, "Y");



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x48631cf9, "i2c_register_driver" },
	{ 0x3ee5992, "ksz_switch_shutdown" },
	{ 0xf1415646, "ksz_switch_remove" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xdcb764ad, "memset" },
	{ 0x595757d9, "ksz_switch_alloc" },
	{ 0x4829a47e, "memcpy" },
	{ 0x86ca91d5, "__devm_regmap_init_i2c" },
	{ 0x6ef6aaa5, "ksz_switch_register" },
	{ 0x6b96d755, "dev_err_probe" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xa542f7bf, "i2c_del_driver" },
	{ 0x3757b2ea, "ksz_switch_chips" },
	{ 0x47e64c59, "module_layout" },
};

MODULE_INFO(depends, "ksz_switch,regmap-i2c");

MODULE_ALIAS("of:N*T*Cmicrochip,ksz9477");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9477C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9896");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9896C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9897");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9897C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9893");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9893C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9563");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9563C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8563");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8563C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8567");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz8567C*");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9567");
MODULE_ALIAS("of:N*T*Cmicrochip,ksz9567C*");
MODULE_ALIAS("i2c:ksz9477-switch");

MODULE_INFO(srcversion, "E81FECCD24CA3C84B39BBA1");
